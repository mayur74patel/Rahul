from django.http import Http404
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK
from rest_framework.views import APIView
from rest_framework import generics

from resolab_api.core.models import *
from resolab_api.core.serializers import *

# Create your views here.

class RegisterView(generics.GenericAPIView):
    serializer_class = RegisterSerializer

    def post(self, request):
        self.serializer = self.get_serializer(data=request.data)
        self.serializer.is_valid(raise_exception=True)
        self.serializer.save()
        response = ResponseSerializer({ 'response': 'User Registered!' })
        return Response(response.data, HTTP_200_OK)

class LoginView(generics.GenericAPIView):
    serializer_class = LoginSerializer

    def post(self, request):
        self.serializer = self.get_serializer(data=request.data)
        self.serializer.is_valid(raise_exception=True)
        token = self.serializer.get_token_and_user()
        response = ResponseSerializer({ 'response': token })
        return Response(response.data, HTTP_200_OK)

class GetSubscriptionStatus(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        try:
            user_profile = UserProfile.objects.get(user = request.user)
            response = ResponseSerializer({ 'response': user_profile.is_subscribed })
            return Response(response.data , HTTP_200_OK)
        except UserProfile.DoesNotExist:
            response = ResponseSerializer({ 'response': 'No matching user exists!' })
            return Response(response.data, HTTP_200_OK)

class JobListView(generics.ListAPIView):
    serializer_class = JobListSerializer
    queryset = Job.objects.all()

class ResourceSeekerCardCreateView(generics.CreateAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = ResourceSeekerCardSerializer
    queryset = ResourceSeekerCard.objects.all()

class ResourceSeekerCardListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = ResourceSeekerCardListSerializer
    queryset = ResourceSeekerCard.objects.all()

class ResourceSeekerCardRetrieveUpdateDeleteView(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = ResourceSeekerCardSerializer
    queryset = ResourceSeekerCard.objects.all()

class ResourceProviderCardCreateView(generics.CreateAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = ResourceProviderCardSerializer
    queryset = ResourceProviderCard.objects.all()

class ResourceProviderCardListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = ResourceProviderCardListSerializer
    queryset = ResourceProviderCard.objects.all()

class ResourceProviderCardRetrieveUpdateDeleteView(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = ResourceProviderCardSerializer
    queryset = ResourceProviderCard.objects.all()
