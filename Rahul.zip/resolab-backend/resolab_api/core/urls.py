from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns

from resolab_api.core.views import *

urlpatterns = [
    path('login/', LoginView.as_view()),
    path('register/', RegisterView.as_view()),
    path('list_jobs/', JobListView.as_view()),
    path('create_seeker/', ResourceSeekerCardCreateView.as_view()),
    path('list_seekers/', ResourceSeekerCardListView.as_view()),
    path('modify_seeker/<int:pk>/', ResourceSeekerCardRetrieveUpdateDeleteView.as_view()),
    path('create_provider/', ResourceProviderCardCreateView.as_view()),
    path('list_providers/', ResourceProviderCardListView.as_view()),
    path('modify_provider/<int:pk>/', ResourceProviderCardRetrieveUpdateDeleteView.as_view()),
    path('get_sub_status/', GetSubscriptionStatus.as_view())
]

urlpatterns = format_suffix_patterns(urlpatterns)
