from django.contrib import admin

from resolab_api.core.models import *

# Register your models here.

admin.site.register(UserProfile)
admin.site.register(Industry)
admin.site.register(ResourceType)
admin.site.register(ResourceCategory)
admin.site.register(Job)
admin.site.register(ResourceSeekerCard)
admin.site.register(ResourceProviderCard)
