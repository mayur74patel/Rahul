import React from 'react';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.min.css';
import 'owl.carousel/dist/assets/owl.theme.default.min.css';

import CardTemplateForProvider from './CardTemplateForProvider.js';
import CardTemplateForSeeker from './CardTemplateForSeeker.js';
import CardTemplateForHighlights from './CardTemplateForHighlights.js';
import frank from '../images/frank.jpg';
import '../style/css/CardDeckTemplate.css';

let providerCards=[{
    cId: 1,
    cUser: 'frank',
    cName: 'Frank Abagnale',
    cPosition: 'Domain Trainer',
    cMoney: 30000,
    cLoc: 'Ahmedabad',
    jobTypeVal: 0,
    postedByVal: 2,
}, {
    cId: 2,
    cUser: 'frank',
    cName: 'Will Smith',
    cPosition: 'Domain Trainer',
    cMoney: 20000,
    cLoc: 'Ayodhya',
    jobTypeVal: 0,
    postedByVal: 2,
}, {
    cId: 3,
    cUser: 'frank',
    cName: 'Abhas K D',
    cPosition: 'Domain Trainer',
    cMoney: 20000,
    cLoc: 'Andheri',
    jobTypeVal: 0,
    postedByVal: 2,
}, {
    cId:4,
    cUser: 'frank',
    cName: 'Tracy Smith',
    cPosition: 'Logistics Manager',
    cMoney: 35000,
    cLoc: 'Dharavi',
    jobTypeVal: 0,
    postedByVal: 2,
}, {
    cId: 5,
    cUser: 'frank',
    cName: 'Heinrisch Schindler',
    cPosition: 'Factory Manager',
    cMoney: 23000,
    cLoc: 'Jacksonville',
    jobTypeVal: 0,
    postedByVal: 2,
}, {
    cId: 6,
    cUser: 'frank',
    cName: 'Heinrisch Schindler',
    cPosition: 'Factory Manager',
    cMoney: 23000,
    cLoc: 'Jacksonville',
    jobTypeVal: 0,
    postedByVal: 2,
},];

let cardsForSeeker=[{
    cCategory: 'Trainer',
    cSubCategory: 'Domain Trainer',
    cSalaryLower: 20000,
    cSalaryUpper: 50000,
    postedByVal: 0,
    cImg: 'frank',
    cLoc: 'Rajkot',
    cId: 0,
}, {
    cCategory: 'Trainer',
    cSubCategory: 'IT Trainer',
    cSalaryLower: 25000,
    cSalaryUpper: 50000,
    postedByVal: 0,
    cImg: 'frank',
    cLoc: 'Rajkot',
    cId: 1,
}, {
    cCategory: 'Operation',
    cSubCategory: 'MIS Executive',
    cSalaryLower: 30000,
    cSalaryUpper: 50000,
    postedByVal: 0,
    cImg: 'frank',
    cLoc: 'Rajkot',
    cId: 2,
}, {
    cCategory: 'Quality',
    cSubCategory: 'State Quality Head',
    cSalaryLower: 15000,
    cSalaryUpper: 50000,
    postedByVal: 1,
    cImg: 'frank',
    cLoc: 'Rajkot',
    cId: 3,
}, {
    cCategory: 'Finance',
    cSubCategory: 'Finance Head',
    cSalaryLower: 30000,
    cSalaryUpper: 50000,
    postedByVal: 1,
    cImg: 'frank',
    cLoc: 'Rajkot',
    cId: 4,
}, ];

function CardDeckTemplate(props) {
	
		
			if(props.cdType==="available"){
			{/*Show 12 cards from available-resources data*/}
				var icount=4;
				var nval=true;
				var toutvar=1000;
				var dval=true;

				var deck=providerCards.map((card)=>{
                                return(<CardTemplateForProvider cUser={card.cUser}
                                             cName={card.cName}
                                             cPosition={card.cPosition}
                                             cMoney={card.cMoney}
                                             cLoc={card.cLoc}
                                             cImg={frank}
                                             key={card.cId}
                                              />)
                            });
				
				
			}else if(props.cdType==="required"){
				var icount=4;
				var nval=true;
				var toutvar=1000;
				var dval=true;
				var deck=cardsForSeeker.map((card)=>{
                                return(<CardTemplateForSeeker
                                             cCategory={card.cCategory}
                                             cSubCategory={card.cSubCategory}
                                             cSalaryLower={card.cSalaryLower}
                                             cSalaryUpper={card.cSalaryUpper}
                                             cPostedByVal={card.cPostedByVal}
                                             cImg={card.cImg}
                                             cLoc={card.cLoc}
                                             key={card.cId}

                                              />)
                            })

			}else if(props.cdType==="highlights"){
				var deck=['image1','image2','image3','image4',].map((card)=>{
					return (
						<div className="item" style={{width:"300px"}}>
							<CardTemplateForHighlights cStat={card} />
						</div>
						)
				})

				var icount=3;
				var nval=false;
				var toutvar=2500;
				var dval=false;
			}


	return(
		<OwlCarousel
			items={icount}
			className="owl-theme"
			autoplay
			center={false}
			nav={false}
			autoplayTimeout={toutvar}
			autoplayHoverPause={dval}
			loop
			dots={false}
			responsiveClass={true}
    		responsive={{
        0:{
            items:2,
        },
        600:{
            items:2,
        },
        1000:{
            items:icount,
        }	
        }
    }

		>
		{/* We need to add, say, 16 entries in the deck*/}
		
			{deck}
			
		</OwlCarousel>
	);
}

export default CardDeckTemplate;