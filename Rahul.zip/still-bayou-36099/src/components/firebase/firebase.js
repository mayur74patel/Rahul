import firebase from 'firebase';

const config={
    apiKey: "AIzaSyANL6igyMS-U3kBxIKgv8n7MJXsscAf0qI",
    authDomain: "my-firebase-e9059.firebaseapp.com",
    databaseURL: "https://my-firebase-e9059.firebaseio.com",
    projectId: "my-firebase-e9059",
    storageBucket: "my-firebase-e9059.appspot.com",
    messagingSenderId: "963326711937",
    appId: "1:963326711937:web:685992e96d7324cea31580"
}
firebase.initializeApp(config);
export default firebase;